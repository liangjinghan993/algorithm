#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct State {
    int teacher[4];
    int time[4];
    int cost;
};

const int teacher_time[4][4] = {
    {2, 10, 9, 7},
    {15, 4, 14, 8},
    {13, 14, 16, 11},
    {4, 15, 13, 9}
};

State initial_state = { {-1, -1, -1, -1}, {0, 0, 0, 0}, 0 };

vector<State> expand_state(State s) {
    vector<State> states;
    for (int t = 0; t < 4; t++) {
        if (s.teacher[t] == -1) {
            for (int c = 0; c < 4; c++) {
                bool conflict = false;
                for (int i = 0; i < 4; i++) {
                    if (s.teacher[i] == c) {
                        conflict = true;
                        break;
                    }
                }
                if (!conflict) {
                    State new_state = s;
                    new_state.teacher[t] = c;
                    new_state.time[c] += teacher_time[t][c];
                    new_state.cost = s.cost + teacher_time[t][c];
                    states.push_back(new_state);
                }
            }
        }
    }
    return states;
}

bool operator<(const State& a, const State& b) {
    return a.cost > b.cost;
}

int solve() {
    priority_queue<State> q;
    q.push(initial_state);
    while (!q.empty()) {
        State s = q.top();
        q.pop();
        if (s.cost == 53) {
            // �ҵ����Ž⣬������
            cout << "Course 1: Teacher " << s.teacher[0] << " (" << teacher_time[0][s.teacher[0]] << " hours)" << endl;
            cout << "Course 2: Teacher " << s.teacher[1] << " (" << teacher_time[1][s.teacher[1]] << " hours)" << endl;
            cout << "Course 3: Teacher " << s.teacher[2] << " (" << teacher_time[2][s.teacher[2]] << " hours)" << endl;
            cout << "Course 4: Teacher " << s.teacher[3] << " (" << teacher_time[3][s.teacher[3]] << " hours)" << endl;
            return s.cost;
        }
        vector<State> states = expand_state(s);
        for (State new_state : states) {
            q.push(new_state);
        }
    }
    return -1; // �޽�
}

int main() {
    int cost = solve();
    if (cost == -1) {
        cout << "No solution." << endl;
    }
    else {
        cout << "Minimum cost: " << cost << " hours." << endl;
    }
    return 0;
}