#include <iostream>
#include <string>
using namespace std;

int findSubstring(const string& X, const string& Y) {
    int n = X.length();
    int m = Y.length();

    if (m > n) {
        return -1;
    }

    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && X[i + j] == Y[j]) {
            j++;
        }

        if (j == m) {
            return i;
        }
    }

    return -1;
}

int main() {
    string X, Y;
    cout << "Enter the string X: ";
    cin >> X;
    cout << "Enter the string Y: ";
    cin >> Y;

    int position = findSubstring(X, Y);
    cout << "Y appears in X at position: " << position << endl;

    return 0;
}
