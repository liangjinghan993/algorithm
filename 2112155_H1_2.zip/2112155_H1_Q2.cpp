#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int n, m, a, b;
    cin >> n >> m >> a >> b;

    if (b / m < a) { // It's cheaper to buy m-ride tickets
        int full_price_rides = n % m;
        int num_m_tickets = n / m;
        int total_cost = num_m_tickets * b;
        if (full_price_rides > 0) {
            total_cost += min(full_price_rides * a, b);
        }
        cout << total_cost << endl;
    }
    else { // It's cheaper to buy one-ride tickets
        cout << n * a << endl;
    }

    return 0;
}