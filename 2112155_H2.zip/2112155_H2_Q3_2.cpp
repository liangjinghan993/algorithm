
//O(n^2)
#include <iostream>
#include <vector>
using namespace std;
vector<int> twoSum(vector<int>& nums, int target)
{
	for (int i = 0; i < nums.size() - 1; i++)
	{
		for (int j = i + 1; j < nums.size(); j++)
		{
			if (nums[i] + nums[j] == target) {
				return{ i,j };
			}
		}
	}
	return {};
}
int main()
{
	vector<int>nums = { 1,3,5,7,9 };
	int target = 12;
	vector<int>result = twoSum(nums, target);
	if (result.empty()) {
		cout << "No two sum solution" << endl;
	}
	else {
		cout << "Indices:" << result[0] << "," << result[1] << endl;
		cout << "Values:" << nums[result[0]] << "," << nums[result[1]] << endl;
	}
	return 0;
}