#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

struct Point {
    double x, y;
};

// ��������֮��ľ���
double distance(Point p1, Point p2) {
    double dx = p1.x - p2.x;
    double dy = p1.y - p2.y;
    return sqrt(dx * dx + dy * dy);
}

// ���� x ��������
bool compareX(Point p1, Point p2) {
    return p1.x < p2.x;
}

// ���� y ��������
bool compareY(Point p1, Point p2) {
    return p1.y < p2.y;
}

// �����㷨�����̾���
double closestPair(vector<Point>& points, int start, int end) {
    if (end - start <= 3) {
        // ������С�ڵ��� 3 ��ʱ��ֱ�Ӽ�����С����
        double minDist = 1e9;
        for (int i = start; i < end; i++) {
            for (int j = i + 1; j < end; j++) {
                minDist = min(minDist, distance(points[i], points[j]));
            }
        }
        return minDist;
    }

    int mid = (start + end) / 2;
    double distLeft = closestPair(points, start, mid);
    double distRight = closestPair(points, mid, end);
    double dist = min(distLeft, distRight);

    // ��������������ĵ��֮��ľ���
    vector<Point> strip;
    for (int i = start; i < end; i++) {
        if (abs(points[i].x - points[mid].x) < dist) {
            strip.push_back(points[i]);
        }
    }
    sort(strip.begin(), strip.end(), compareY);
    int size = strip.size();
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size && strip[j].y - strip[i].y < dist; j++) {
            dist = min(dist, distance(strip[i], strip[j]));
        }
    }

    return dist;
}

double closestPair(vector<Point>& points) {
    sort(points.begin(), points.end(), compareX);
    return closestPair(points, 0, points.size());
}

int main() {
    int n;
    cout << "Enter the number of points: ";
    cin >> n;

    vector<Point> points(n);
    for (int i = 0; i < n; i++) {
        cout << "Enter the coordinates of point " << i + 1 << ": ";
        cin >> points[i].x >> points[i].y;
    }

    double minDist = closestPair(points);
    cout << "The closest pair has distance " << minDist << endl;

    return 0;
}