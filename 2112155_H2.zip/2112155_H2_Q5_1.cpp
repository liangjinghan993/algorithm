#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

vector<int> threeSum(vector<int>& nums, int target) {
    vector<int> result;
    int n = nums.size();

    unordered_map<int, int> mp;

    for (int i = 0; i < n; i++) {
        mp[nums[i]] = i;
    }

    for (int i = 0; i < n - 2; i++) {
        for (int j = i + 1; j < n - 1; j++) {
            int complement = target - nums[i] - nums[j];

            if (mp.find(complement) != mp.end() && mp[complement] > j) {
                result.push_back(nums[i]);
                result.push_back(nums[j]);
                result.push_back(complement);
                return result;
            }
        }
    }

    return result;
}

int main() {
    int n, target;
    cin >> n >> target;
    vector<int> nums(n);
    for (int i = 0; i < n; i++)
    {
        cin >> nums[i];
    }
    vector<int> res = threeSum(nums, target);
    if (res.empty()) {
        cout << "No result!" << endl;
    }
    else {
        cout << res[0] << " " << res[1] << " " << res[2] << endl;
    }
    return 0;
}//��ϣ��