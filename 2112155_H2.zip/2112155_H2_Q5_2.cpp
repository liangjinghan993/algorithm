#include <iostream>
#include <vector>

using namespace std;

vector<int> threeSum(vector<int>& nums, int target) {
    vector<int> res;
    int n = nums.size();
    for (int i = 0; i < n - 2; i++) {
        for (int j = i + 1; j < n - 1; j++) {
            for (int k = j + 1; k < n; k++) {
                if (nums[i] + nums[j] + nums[k] == target) {
                    res.push_back(nums[i]);
                    res.push_back(nums[j]);
                    res.push_back(nums[k]);
                    return res;
                }
            }
        }
    }
    return res;
}

int main() {
    int n, target;
    cin >> n >> target;
    vector<int> nums(n);
    for (int i = 0; i < n; i++)
    {
        cin >> nums[i];
    }
    vector<int> res = threeSum(nums, target);
    if (res.empty()) {
        cout << "No result!" << endl;
    }
    else {
        cout << res[0] << " " << res[1] << " " << res[2] << endl;
    }
    return 0;
}//����ѭ��