#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> threeSum(vector<int>& nums, int target) {
    vector<int> res;
    int n = nums.size();
    sort(nums.begin(), nums.end());
    for (int i = 0; i < n - 2; i++) {
        int l = i + 1, r = n - 1;
        while (l < r) {
            int sum = nums[i] + nums[l] + nums[r];
            if (sum == target) {
                res.push_back(nums[i]);
                res.push_back(nums[l]);
                res.push_back(nums[r]);
                return res;
            }
            else if (sum < target) {
                l++;
            }
            else {
                r--;
            }
        }
    }
    return res;
}

int main() {
    int n, target;
    cin >> n >> target;
    vector<int> nums(n);
    for (int i = 0; i < n; i++)
    {
        cin >> nums[i];
    }
    vector<int> res = threeSum(nums, target);
    if (res.empty()) {
        cout << "No result!" << endl;
    }
    else {
        cout << res[0] << " " << res[1] << " " << res[2] << endl;
    }
    return 0;
}//˫ָ��