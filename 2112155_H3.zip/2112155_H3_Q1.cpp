#include <iostream>
#include <queue>
#include <vector>
using namespace std;

const int MAXN = 10005;
vector<int> graph[MAXN];
int level[MAXN];

void BFS(int s) {
    queue<int> q;
    q.push(s);
    level[s] = 0;
    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        for (int i = 0; i < graph[cur].size(); i++) {
            int nxt = graph[cur][i];
            if (level[nxt] == -1) { // ���nxtû�б����ʹ�
                level[nxt] = level[cur] + 1;
                q.push(nxt);
            }
        }
    }
}

int main() {
    int n, m, s;
    cin >> n >> m >> s;
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    // ��ʼ��level���飬-1��ʾδ���ʹ�
    fill(level, level + n, -1);
    BFS(s);
    for (int i = 0; i < n; i++) {
        cout << level[i] << " ";
    }
    cout << endl;
    return 0;
}