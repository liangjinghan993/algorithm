#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <algorithm>

using namespace std;

// BFS connected component algorithm
vector<int> bfs(int start, vector<vector<int>>& graph, vector<bool>& visited) {
    vector<int> result;
    queue<int> q;
    q.push(start);
    visited[start] = true;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        result.push_back(node);
        for (int neighbor : graph[node]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }
    }
    sort(result.begin(), result.end());
    return result;
}

// DFS connected component algorithm
vector<int> dfs(int start, vector<vector<int>>& graph, vector<bool>& visited) {
    vector<int> result;
    stack<int> s;
    s.push(start);
    visited[start] = true;
    while (!s.empty()) {
        int node = s.top();
        s.pop();
        result.push_back(node);
        for (int neighbor : graph[node]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                s.push(neighbor);
            }
        }
    }
    sort(result.begin(), result.end());
    return result;
}

int main() {
    int n, m, start;
    cin >> n >> m >> start;

    // build graph
    vector<vector<int>> graph(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    // BFS
    vector<bool> visited(n, false);
    vector<int> bfs_result = bfs(start, graph, visited);
    for (int node : bfs_result) {
        cout << node << " ";
    }
    cout << endl;

    // DFS
    visited.assign(n, false);
    vector<int> dfs_result = dfs(start, graph, visited);
    for (int node : dfs_result) {
        cout << node << " ";
    }
    cout << endl;

    return 0;
}