#include <iostream>
#include <vector>
#include <queue>

using namespace std;

bool isBipartite(vector<vector<int>>& graph, int start) {
    int n = graph.size();
    vector<int> colors(n, -1); // initialize all nodes as uncolored
    queue<int> q;
    q.push(start);
    colors[start] = 0; // color starting node with 0

    while (!q.empty()) {
        int curr = q.front();
        q.pop();

        for (int neighbor : graph[curr]) {
            if (colors[neighbor] == -1) { // uncolored node
                colors[neighbor] = 1 - colors[curr]; // color with opposite color
                q.push(neighbor);
            }
            else if (colors[neighbor] == colors[curr]) { // neighbor has same color as curr
                return false; // odd cycle found
            }
        }
    }
    return true; // no odd cycles found, graph is bipartite
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> graph(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    bool bipartite = true;
    for (int i = 0; i < n; i++) {
        if (isBipartite(graph, i) == false) {
            bipartite = false;
            break;
        }
    }

    if (bipartite) {
        cout << "Yes" << endl;
    }
    else {
        cout << "No" << endl;
    }

    return 0;
}