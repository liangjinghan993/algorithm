#include <iostream>
#include <algorithm>
using namespace std;
const int MAX = 1e5 + 1;
int n, partitioning, t;
pair<int, int>interval[MAX];
int main() {
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> interval[i].second >> interval[i].first;
	}
	sort(interval + 1, interval + n + 1);
	for (int i = 1; i <= n; i++) {
		if (t < interval[i].second) {
			partitioning++;
			t = interval[i].first;
		}
	}
	cout << partitioning;
	return 0;
}