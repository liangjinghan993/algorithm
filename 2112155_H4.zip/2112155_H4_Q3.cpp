//��С������ӳ��㷨
#include <iostream>
#include <algorithm>
using namespace std;

const int MAX_SIZE = 200;

struct Request {
    int processtime, deadline;
    int begin, end;
} req[MAX_SIZE];

bool operator<(const Request& req1, const Request& req2) {
    return req1.deadline < req2.deadline;
}

int main() {
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> req[i].processtime >> req[i].deadline;
    }

    sort(req, req + n);

    int start = 0, maxdelay = 0;
    for (int i = 0; i < n; i++) {
        req[i].begin = start;
        req[i].end = start + req[i].processtime;
        start += req[i].processtime;
        if (maxdelay < req[i].end - req[i].deadline) {
            maxdelay = req[i].end - req[i].deadline;
        }
    }

    cout << maxdelay << endl;
    return 0;
}