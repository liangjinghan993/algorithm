#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

vector<int> optimalCache(int k, int n, vector<int>& requests) {
    unordered_map<int, int> cache;
    vector<int> evictionSchedule;

    for (int i = 0; i < requests.size(); i++) {
        int block = requests[i];

        if (cache.find(block) != cache.end()) { // block found in cache
            cache[block] = i;
            continue;
        }

        if (cache.size() == k) { // cache is full, need to evict
            int farthestBlock = -1;
            int farthestDistance = -1;

            for (auto it = cache.begin(); it != cache.end(); it++) {
                int distance = requests.size();
                for (int j = i + 1; j < requests.size(); j++) {
                    if (requests[j] == it->first) {
                        distance = j - i;
                        break;
                    }
                }

                if (distance > farthestDistance) {
                    farthestBlock = it->first;
                    farthestDistance = distance;
                }
            }

            cache.erase(farthestBlock);
            evictionSchedule.push_back(farthestBlock);
        }

        cache[block] = i;
    }

    return evictionSchedule;
}

int main() {
    int k, n, s;
    cin >> k >> n >> s;

    vector<int> initialBlocks(n);
    for (int i = 0; i < n; i++) {
        cin >> initialBlocks[i];
    }

    vector<int> requests(s);
    for (int i = 0; i < s; i++) {
        cin >> requests[i];
    }

    vector<int> evictionSchedule = optimalCache(k, n, requests);

    for (int i = 0; i < evictionSchedule.size(); i++) {
        cout << evictionSchedule[i] << " ";
    }

    return 0;
}
