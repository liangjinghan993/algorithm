#include <iostream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

typedef pair<int, int> pii; // (distance, vertex)

const int INF = numeric_limits<int>::max();

void dijkstra(const vector<vector<pii>>& graph, int source, vector<int>& dist, vector<int>& prev) {
    int n = graph.size();
    dist.assign(n, INF);
    prev.assign(n, -1);
    dist[source] = 0;
    priority_queue<pii, vector<pii>, greater<pii>> pq; // min-heap of (distance, vertex)
    pq.push({ 0, source });
    while (!pq.empty()) {
        int u = pq.top().second;
        int d = pq.top().first;
        pq.pop();
        if (d > dist[u]) continue; // skip outdated pair
        for (const auto& e : graph[u]) {
            int v = e.first;
            int w = e.second;
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                prev[v] = u;
                pq.push({ dist[v], v });
            }
        }
    }
}

vector<int> shortest_path(int destination, const vector<int>& prev) {
    vector<int> path;
    while (destination != -1) {
        path.push_back(destination);
        destination = prev[destination];
    }
    reverse(path.begin(), path.end());
    return path;
}

int main() {
    int n, e, s;
    cin >> n >> e >> s;
    vector<vector<pii>> graph(n);
    for (int i = 0; i < e; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        graph[u - 1].push_back({ v - 1, w });
    }
    vector<int> dist, prev;
    dijkstra(graph, s - 1, dist, prev);
    for (int i = 0; i < n; i++) {
        cout << dist[i] << " ";
    }
    cout << endl;
    return 0;
}
