#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int N = 100005;

struct edge {
    int u, v, w;
    bool operator<(const edge& e) const {
        return w < e.w;
    }
};

int p[N];

int find(int x) {
    if (p[x] == x) return x;
    return p[x] = find(p[x]);
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<edge> edges(m);
    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        edges[i] = { u, v, w };
    }
    sort(edges.begin(), edges.end());
    for (int i = 1; i <= n; i++) {
        p[i] = i;
    }
    int ans = 0;
    for (int i = 0; i < m; i++) {
        int u = edges[i].u, v = edges[i].v, w = edges[i].w;
        int pu = find(u), pv = find(v);
        if (pu != pv) {
            p[pu] = pv;
            ans += w;
        }
    }
    cout << ans << endl;
    return 0;
}
