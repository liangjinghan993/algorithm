#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// A structure to represent an edge in the graph
struct Edge {
    int src, dest, weight;
};

// A structure to represent a subset for union-find
struct Subset {
    int parent, rank;
};

// A class to represent a graph
class Graph {
public:
    int V, E;
    vector<Edge> edges;

    // Constructor
    Graph(int V, int E) {
        this->V = V;
        this->E = E;
    }

    // Add an edge to the graph
    void addEdge(int src, int dest, int weight) {
        edges.push_back({ src, dest, weight });
    }

    // Find the subset of an element
    int find(Subset subsets[], int i) {
        if (subsets[i].parent != i)
            subsets[i].parent = find(subsets, subsets[i].parent);

        return subsets[i].parent;
    }

    // Union two subsets
    void Union(Subset subsets[], int x, int y) {
        int xroot = find(subsets, x);
        int yroot = find(subsets, y);

        if (subsets[xroot].rank < subsets[yroot].rank)
            subsets[xroot].parent = yroot;
        else if (subsets[xroot].rank > subsets[yroot].rank)
            subsets[yroot].parent = xroot;
        else {
            subsets[yroot].parent = xroot;
            subsets[xroot].rank++;
        }
    }

    // Kruskal's algorithm
    int kruskalMST() {
        vector<Edge> result;
        Subset* subsets = new Subset[V];

        // Sort edges by weight
        sort(edges.begin(), edges.end(), [](Edge a, Edge b) {
            return a.weight < b.weight;
            });

        // Create V subsets with single elements
        for (int i = 0; i < V; i++) {
            subsets[i].parent = i;
            subsets[i].rank = 0;
        }

        int i = 0;
        while (result.size() < V - 1 && i < E) {
            Edge next_edge = edges[i++];

            int x = find(subsets, next_edge.src);
            int y = find(subsets, next_edge.dest);

            if (x != y) {
                result.push_back(next_edge);
                Union(subsets, x, y);
            }
        }

        int sum = 0;
        for (Edge edge : result) {
            sum += edge.weight;
        }

        return sum;
    }
};

int main() {
    int n, m;
    cin >> n >> m;

    Graph g(n, m);

    for (int i = 0; i < m; i++) {
        int src, dest, weight;
        cin >> src >> dest >> weight;
        g.addEdge(src - 1, dest - 1, weight);
    }

    int sum = g.kruskalMST();

    cout << sum << endl;

    return 0;
}
