#include <iostream>
#include <queue>
#include <vector>
#include <unordered_map>

using namespace std;

// A tree node
struct Node {
    char ch;
    int freq;
    Node* left;
    Node* right;
};

// Compare two nodes based on frequency
struct Compare {
    bool operator()(Node* a, Node* b) {
        return a->freq > b->freq;
    }
};

// Traverse the Huffman tree and generate codes
void generateCodes(Node* root, string code, unordered_map<char, string>& codes) {
    if (root == nullptr) {
        return;
    }

    if (root->ch != '\0') {
        codes[root->ch] = code;
    }

    generateCodes(root->left, code + "0", codes);
    generateCodes(root->right, code + "1", codes);
}

// Build the Huffman tree
Node* buildHuffmanTree(vector<int>& freqs) {
    priority_queue<Node*, vector<Node*>, Compare> pq;

    // Create a leaf node for each character and add it to the priority queue
    for (char ch = 'A'; ch <= 'A' + freqs.size() - 1; ch++) {
        if (freqs[ch - 'A'] > 0) {
            Node* leaf = new Node{ ch, freqs[ch - 'A'], nullptr, nullptr };
            pq.push(leaf);
        }
    }

    // Merge two nodes with the lowest frequency until there is only one node left in the queue
    while (pq.size() > 1) {
        Node* left = pq.top();
        pq.pop();

        Node* right = pq.top();
        pq.pop();

        Node* parent = new Node{ '\0', left->freq + right->freq, left, right };
        pq.push(parent);
    }

    return pq.top();
}

// Calculate the average code length
double calculateAverageLength(unordered_map<char, string>& codes, vector<int>& freqs) {
    double sum = 0.0;
    int total_freq = 0;

    for (char ch = 'A'; ch <= 'A' + freqs.size() - 1; ch++) {
        if (freqs[ch - 'A'] > 0) {
            sum += codes[ch].length() * freqs[ch - 'A'];
            total_freq += freqs[ch - 'A'];
        }
    }

    return sum / total_freq;
}

int main() {
    int n;
    cin >> n;

    vector<int> freqs(n);
    for (int i = 0; i < n; i++) {
        cin >> freqs[i];
    }

    // Build the Huffman tree
    Node* root = buildHuffmanTree(freqs);

    // Generate Huffman codes for each character
    unordered_map<char, string> codes;
    generateCodes(root, "", codes);

    // Calculate the average code length
    double avg_len = calculateAverageLength(codes, freqs);

    // Print the result
    cout<< avg_len;

    return 0;
}
