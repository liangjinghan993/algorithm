#include <iostream>
#include <vector>

using namespace std;

// Merge two sorted subarrays [left, mid] and [mid+1, right]
long long merge(vector<int>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    vector<int> left_arr(n1);
    vector<int> right_arr(n2);

    for (int i = 0; i < n1; i++) {
        left_arr[i] = arr[left + i];
    }

    for (int i = 0; i < n2; i++) {
        right_arr[i] = arr[mid + 1 + i];
    }

    int i = 0;
    int j = 0;
    int k = left;
    long long inversions = 0;

    // Merge the two subarrays into the original array
    while (i < n1 && j < n2) {
        if (left_arr[i] <= right_arr[j]) {
            arr[k] = left_arr[i];
            i++;
        }
        else {
            arr[k] = right_arr[j];
            j++;
            inversions += n1 - i; // Increment the number of inversions
        }
        k++;
    }

    // Copy the remaining elements of left_arr
    while (i < n1) {
        arr[k] = left_arr[i];
        i++;
        k++;
    }

    // Copy the remaining elements of right_arr
    while (j < n2) {
        arr[k] = right_arr[j];
        j++;
        k++;
    }

    return inversions;
}

// Count the number of inversions in the subarray [left, right] using merge sort
long long countInversions(vector<int>& arr, int left, int right) {
    if (left >= right) {
        return 0;
    }

    int mid = left + (right - left) / 2;

    // Count the number of inversions in the left half
    long long inversions_left = countInversions(arr, left, mid);

    // Count the number of inversions in the right half
    long long inversions_right = countInversions(arr, mid + 1, right);

    // Count the number of inversions between the two halves
    long long inversions_merge = merge(arr, left, mid, right);

    // Return the total number of inversions
    return inversions_left + inversions_right + inversions_merge;
}

int main() {
    int n;
    cin >> n;

    vector<int> arr(n);
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Count the number of inversions using divide-and-conquer
    long long inversions = countInversions(arr, 0, n - 1);

    // Print the number of inversions
    cout << inversions << endl;

    return 0;
}
