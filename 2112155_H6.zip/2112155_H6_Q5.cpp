#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;

struct Point {
    double x, y;
};

bool comp_x(Point a, Point b) {
    return a.x < b.x;
}

bool comp_y(Point a, Point b) {
    return a.y < b.y;
}

double dist(Point a, Point b) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return sqrt(dx * dx + dy * dy);
}

double brute_force(vector<Point>& points, int l, int r) {
    double res = 1e9;
    for (int i = l; i <= r; i++) {
        for (int j = i + 1; j <= r; j++) {
            res = min(res, dist(points[i], points[j]));
        }
    }
    return res;
}

double closest_points(vector<Point>& points, int l, int r) {
    if (r - l <= 3) return brute_force(points, l, r);

    int mid = (l + r) / 2;
    double d1 = closest_points(points, l, mid);
    double d2 = closest_points(points, mid + 1, r);
    double d = min(d1, d2);

    vector<Point> strip;
    for (int i = l; i <= r; i++) {
        if (abs(points[i].x - points[mid].x) < d) {
            strip.push_back(points[i]);
        }
    }

    sort(strip.begin(), strip.end(), comp_y);
    int n = strip.size();
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n && strip[j].y - strip[i].y < d; j++) {
            d = min(d, dist(strip[i], strip[j]));
        }
    }
    return d;
}

int main() {
    int n;
    cin >> n;
    vector<Point> points(n);
    for (int i = 0; i < n; i++) {
        cin >> points[i].x >> points[i].y;
    }
    sort(points.begin(), points.end(), comp_x);
    double d = closest_points(points, 0, n - 1);
    cout << d *d<< endl;
    return 0;
}
