#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

struct Node {
    int tA;
    int tB;
    int kA;
    int kB;
};

bool compareNodeByTime(const Node& node1, const Node& node2) {
    return max(node1.tA * node1.kA, node1.tB * node1.kB) > max(node2.tA * node2.kA, node2.tB * node2.kB);
}

int main() {
    ifstream inputFile("hpc.in");
    ofstream outputFile("hpc.out");

    int An, Bn, p;
    inputFile >> An >> Bn >> p;

    vector<Node> nodes(p);
    for (int i = 0; i < p; i++) {
        inputFile >> nodes[i].tA >> nodes[i].tB >> nodes[i].kA >> nodes[i].kB;
    }

    sort(nodes.begin(), nodes.end(), compareNodeByTime);

    int totalTime = 0;
    int maxTime = 0;
    for (int i = 0; i < p; i++) {
        int nodeTime = max(nodes[i].tA * An, nodes[i].tB * Bn);
        totalTime = max(totalTime, maxTime + nodeTime);
        maxTime += max(nodes[i].tA * nodes[i].kA, nodes[i].tB * nodes[i].kB);
    }

    outputFile << totalTime << endl;

    inputFile.close();
    outputFile.close();

    return 0;
}
